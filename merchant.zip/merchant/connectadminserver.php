<?php

$servername = "localhost";
$username = "u321728539_udtxasd";
$password = "#**m*axhfhAhjgsajtrybzgutaer$";
$dbname = "u321728539_userdatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);

    header('Location: ' . $serverhost .'/logout.php');
    exit();
}

//echo "Connected";
?>
