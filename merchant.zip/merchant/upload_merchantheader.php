<?php


require 'cookiesvariablesmerchant.php';


// Decryption System Starts Here

// Store the cipher method
$ciphering = "AES-128-CTR";

// Use OpenSSl Encryption method
$iv_length = openssl_cipher_iv_length($ciphering);
$options = 0;

// Non-NULL Initialization Vector for decryption
$decryption_iv = '8675992784945782';

// Store the decryption key
$decryption_key = "MayeshaMeemMuzahidIslam";


// Decryption System Starts Here



// Intitializing Information
$decryptedMerchantName = "";
$decryptedMerchantOwner = "";
$decryptedMerchantPhone = "";
$decryptedMerchantShortName = "";


//
if(isset($_COOKIE[$cookiemerchantname]) && isset($_COOKIE[$cookiemerchantowner]) && isset($_COOKIE[$cookiemerchantphone]) && isset($_COOKIE[$cookiemerchantshortname])) {

  $decryptedMerchantName = openssl_decrypt ($_COOKIE[$cookiemerchantname], $ciphering,
  $decryption_key, $options, $decryption_iv);
  $decryptedMerchantOwner = openssl_decrypt ($_COOKIE[$cookiemerchantowner], $ciphering,
  $decryption_key, $options, $decryption_iv);
  $decryptedMerchantPhone = openssl_decrypt ($_COOKIE[$cookiemerchantphone], $ciphering,
  $decryption_key, $options, $decryption_iv);
  $decryptedMerchantShortName = openssl_decrypt ($_COOKIE[$cookiemerchantshortname], $ciphering,
  $decryption_key, $options, $decryption_iv);
  // $decryptedMerchantPassword = openssl_decrypt ($_COOKIE[$cookiemerchantpassword], $ciphering,
  // $decryption_key, $options, $decryption_iv);

}else{
  header('Location: ' . $serverhost .'/logout.php');
  exit();
}


?>
